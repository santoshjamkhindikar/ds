#include "node.h"



node::node()
{
	this->next = NULL;
}

node::node(int data)
{
	this->data = data;
	this->next = NULL;
}

int node::getdata()
{
	return this->data;
}

void node::setdata(int data)
{
	this->data = data;
}

node * node::getnext()
{
	return this->next;
}

void node::setnext(node * next)
{
	this->next = next;
}



