#include<iostream>
using namespace std;
class node
{
	int data;
	node * next;
public:
	node();
	node(int data);
	int getdata();
	void setdata(int data);
	node* getnext();
	void setnext(node * next);
	
};

