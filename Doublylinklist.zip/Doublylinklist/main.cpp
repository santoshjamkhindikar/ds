#include"linklist.h";
void main()
{
	linklist l;
	l.insert(25);
	l.insert(50);
	l.insert(75);
	l.insert(100);
	l.insert(125);
	l.insertfirst(150);
	l.display();
	getchar();




}