#include"node.h"
class linklist
{
	node * head;
public:
	linklist();
	bool insert(int data);
	bool insertfirst(int data);
	bool deletfirst();
	bool deletlast();

	void display();

	
};

