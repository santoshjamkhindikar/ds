#include<iostream>
using namespace std;
class node
{
	int data;
	node * next;
	node * prev;
public:
	node();
	node(int data);
	int getdata();
	void setdata(int data);
	node* getnext();
	void setnext(node * next);
	node* getprev();
	void setprev(node * prev);
	
};

