#include "linklist.h"



linklist::linklist()
{
	this->head = NULL;
}

bool linklist::insert(int data)
{
	node* newnode = new node(data);
	if (head == NULL)
	{
		head =newnode;
		return true;
	}
	else
	{
		node * temp = head;
		while (temp->getnext() != head)
		{
			temp = temp->getnext();
		}
		temp->setnext(newnode);
		newnode->setprev(temp->getnext());
		return true;
	}
}

bool linklist::insertfirst(int data)
{
	node * newnode = new node(data);
	if (head == NULL)
	{
		newnode = head;
		return true;
	}
	else
	{
	
	 newnode->setnext(head);
		head = newnode;
		return true;
	}
}

bool linklist::deletfirst()
{
	if (head == NULL)
	{
		return false;
	}
	node* temp = head;
	temp->setnext(head);
	delete temp;
}

bool linklist::deletlast()
{
	node* temp =head;
	node* prev = head;
	temp = temp->getnext();
	while (temp->getnext() != NULL)
	{
		temp = temp->getnext();
		prev = prev->getnext();

	}
	prev->setnext(NULL);
	delete temp;
	return true;

	
}

void linklist::display()
{
	node* temp = head;
	while (temp->getnext() != NULL)
	{
		cout << "values are ::" << temp->getdata()<<endl;
		temp = temp->getnext();
	}
	cout << temp->getdata();
	
}






