#pragma once
#include<iostream>
using namespace std;
class employee
{
	int empid;
	char name[15];
	int sal;
public:
	employee();
	int getid();
	int getsal();
	void accept();
	void display();
	static void selectionsort(employee* e, int num);
	static void sortdisplay(employee*emp,int num);
	static void bubblesort(employee * emp,int num);


	
};

