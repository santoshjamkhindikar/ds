#include "employee.h"



employee::employee()
{
}

int employee::getid()
{
	return this->empid;
}

int employee::getsal()
{
	return this->sal;
}

void employee::accept()
{
	cout << "Enter employee id  :";
	cin >> this->empid;
	cout << "Enter employee salery  :";
	cin >> this->sal;
	cout << "Enter employee name  :";
	cin >> strcpy(this->name, name);
}


void employee::display()
{
	cout << "\nemployee id ::\t" << this->empid;
	cout << "\nemployee name ::\t" << this->name;
	cout << "\nemployee sal ::\t" << this->sal;
}

void employee::selectionsort(employee * e, int num)
{
	int i, j, min;
	for (i = 0; i < num-1 ; i++)
	{
		min = i;
		for (j = i + 1; j < num; j++)
		{
			if (e[j].getid() < e[min].getid())
			{
				employee temp = e[j];
				e[j] = e[min];
				e[min] = temp;
			}

		}
	}
}

void employee::sortdisplay(employee * emp, int num)
{
	for (int i = 0; i < num; i++)
	{
		emp[i].display();
	}
}

void employee::bubblesort(employee * emp, int num)
{
	int i, j;
	for (i = 0; i < num ; i++)
	{
		for (j = 0; j < num-1; j++)
		{
			if (emp[j].getid() > emp[j + 1].getid())
			{
				employee temp = emp[j];
				emp[j] = emp[j + 1];
				emp[j + 1] = temp;
			}
		}
	}
}

//void employee::sort(employee * e, int num)
//{
//	
//}
