#include"employee.h";
#include"conio.h"



int main()
{
	employee emp[4];
	for (int i = 0; i < 4; i++)
	{
		emp[i].accept();

	}
	cout << "bubble sort";
	employee::bubblesort(emp, 4);
	employee::sortdisplay(emp, 4);
	cout << "selection sort";
	employee::selectionsort(emp, 4);
	employee::sortdisplay(emp, 4);

	


	_getch();
	return 0;




}